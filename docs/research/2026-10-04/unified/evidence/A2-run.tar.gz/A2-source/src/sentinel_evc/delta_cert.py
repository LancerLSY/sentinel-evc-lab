"""Δ-Cert 增量重验。

数学基础
--------
设父轨迹对约束 i 在第 k 段已验证剩余下界 rho(i,k)，子轨迹与父轨迹在该段
的状态差异不超过 e(k)，约束函数在相应区域满足 Lipschitz 常数 L(i)，则：

    rho_child(i,k) >= rho_parent(i,k) - L(i) * e(k)

相同时间网格下，第 k 段任意插值点的偏差不超过两端点偏差范数的最大值：

    e(k) = max( ||p'_k - p_k||, ||p'_{k+1} - p_{k+1}|| )

本项目的两类约束 —— 点到固定球的欧氏距离、轴向盒边界 —— 都满足 L=1，
所以每段只需保存一个最小余量，转移检查从 O(H*M) 降到 O(H)。

这是对已有连续性与安全证书思想的应用，不是新的数学定理。项目的增量在于
把它和变换登记、依赖失效、许可生命周期组合起来，并实测成本收益。

两条容易写错的规则
------------------
1. 余量从父的**剩余量**扣减，不是每次回到最初值。
   30mm 先耗 8mm 剩 22，再耗 5mm 剩 17 —— 不是 30-5=25。
2. 继承失败的结论是「无法证明，去做完整检查」，不是「一定会碰撞」。
"""

from __future__ import annotations

import itertools
import math
from dataclasses import dataclass
from typing import Optional

from .contracts import Certificate, Plan, Scene, TransformRecord
from .geometry import full_check

# 本项目约束族的 Lipschitz 常数。整臂推广时这个值不再是 1，
# 拿不到有效界时必须退回 FULL_ONLY，不能沿用。
LIPSCHITZ = 1.0

MAX_INHERIT_DEPTH = 8

_cert_counter = itertools.count(1)


def _next_cert_id() -> str:
    return f"cert-{next(_cert_counter):06d}"


@dataclass
class Verdict:
    """一次判定的完整结果，对应 schemas/verdict.schema.json。"""

    plan_hash: str
    verdict: str  # FULL | INHERITED | REJECTED
    path: str  # parent_only | full | delta
    certificate: Optional[Certificate] = None
    margins: tuple = ()
    first_violation_segment: Optional[int] = None
    full_checks_used: int = 0
    inherit_depth: int = 0
    parent_cert_id: Optional[str] = None
    reason_code: Optional[str] = None

    def summary(self) -> dict:
        return {
            "plan_hash": self.plan_hash,
            "verdict": self.verdict,
            "path": self.path,
            "cert_id": self.certificate.cert_id if self.certificate else None,
            "parent_cert_id": self.parent_cert_id,
            "margins": [round(m, 9) for m in self.margins],
            "first_violation_segment": self.first_violation_segment,
            "full_checks_used": self.full_checks_used,
            "inherit_depth": self.inherit_depth,
            "reason_code": self.reason_code,
        }


def deviation_bounds(parent: Plan, child: Plan) -> tuple:
    """逐段偏差界 e(k)，要求同时间网格、同节点数。"""
    if parent.horizon != child.horizon:
        raise ValueError("时间网格不同，不能按段比较偏差")
    e = []
    for k in range(parent.horizon):
        d0 = math.dist(parent.knots[k], child.knots[k])
        d1 = math.dist(parent.knots[k + 1], child.knots[k + 1])
        e.append(max(d0, d1))
    return tuple(e)


def dependency_ok(
    parent_cert: Certificate,
    parent_plan: Plan,
    child: Plan,
    scene: Scene,
    transform: TransformRecord,
) -> Optional[str]:
    """检查继承的前置依赖。返回失效原因，全部满足时返回 None。

    几何余量够用不代表可以继承 —— 时间网格、事件、场景、变换类型
    任何一项变化都要先挡住。
    """
    if not transform.inheritable:
        return "transform_not_registered"
    if parent_cert.plan_hash != parent_plan.hash:
        return "parent_plan_hash_mismatch"
    if transform.parent_hash != parent_plan.hash:
        return "transform_parent_hash_mismatch"
    if transform.child_hash != child.hash:
        return "transform_child_hash_mismatch"
    if parent_cert.scene_hash != scene.hash:
        return "scene_changed"
    if parent_cert.proof_scope != "numeric-sphere-box-L1-v1":
        return "proof_scope_changed"
    if parent_cert.dt != child.dt:
        return "dt_changed"
    if parent_cert.horizon != child.horizon:
        return "horizon_changed"
    if parent_cert.depth + 1 > MAX_INHERIT_DEPTH:
        return "max_depth_exceeded"
    if parent_plan.descriptor != child.descriptor:
        return "descriptor_changed"
    if parent_plan.gripper_events != child.gripper_events:
        return "gripper_events_changed"
    return None


def validate_or_inherit(
    child: Plan,
    scene: Scene,
    parent_plan: Optional[Plan] = None,
    parent_cert: Optional[Certificate] = None,
    transform: Optional[TransformRecord] = None,
) -> Verdict:
    """路径 c：先试继承，界不够则完整检查。

    这是产品主路径。路径 a（只验父轨迹）和路径 b（总是完整检查）
    在 pipeline.py 里作为对照实现。
    """
    # --- 情形一：无父证书，只能完整检查
    if parent_cert is None or parent_plan is None or transform is None:
        return _full_path(child, scene)

    # --- 情形二：内容完全相同，查过依赖后直接复用
    if parent_cert.plan_hash == child.hash:
        reason = dependency_ok(parent_cert, parent_plan, child, scene, transform)
        if reason is None:
            return Verdict(
                plan_hash=child.hash,
                verdict="INHERITED",
                path="delta",
                certificate=parent_cert,
                margins=parent_cert.margins,
                full_checks_used=0,
                inherit_depth=parent_cert.depth,
                parent_cert_id=parent_cert.cert_id,
            )
        return _full_path(child, scene, parent_cert_id=parent_cert.cert_id)

    # --- 情形三：尝试 Δ 继承
    reason = dependency_ok(parent_cert, parent_plan, child, scene, transform)
    if reason is not None:
        v = _full_path(child, scene, parent_cert_id=parent_cert.cert_id)
        v.reason_code = reason
        return v

    e = deviation_bounds(parent_plan, child)
    # 关键：从父证书的剩余余量扣，不是从最初值扣
    child_margins = tuple(
        parent_cert.margins[k] - LIPSCHITZ * e[k] for k in range(child.horizon)
    )

    if min(child_margins) >= 0.0:
        cert = Certificate(
            cert_id=_next_cert_id(),
            plan_hash=child.hash,
            scene_hash=scene.hash,
            dt=child.dt,
            horizon=child.horizon,
            margins=child_margins,
            method="INHERITED",
            parent_id=parent_cert.cert_id,
            root_id=parent_cert.root_id or parent_cert.cert_id,
            depth=parent_cert.depth + 1,
            plan_exact=child.exact_hash,
        )
        return Verdict(
            plan_hash=child.hash,
            verdict="INHERITED",
            path="delta",
            certificate=cert,
            margins=child_margins,
            full_checks_used=0,
            inherit_depth=cert.depth,
            parent_cert_id=parent_cert.cert_id,
        )

    # 界不够 —— 这只说明「无法证明」，还要真的做完整检查才能下结论
    v = _full_path(child, scene, parent_cert_id=parent_cert.cert_id)
    if v.reason_code is None:
        v.reason_code = "bound_insufficient"
    return v


def _full_path(
    child: Plan, scene: Scene, parent_cert_id: Optional[str] = None
) -> Verdict:
    ok, margins, first_violation = full_check(child, scene)
    if not ok:
        return Verdict(
            plan_hash=child.hash,
            verdict="REJECTED",
            path="full",
            margins=margins,
            first_violation_segment=first_violation,
            full_checks_used=1,
            parent_cert_id=parent_cert_id,
            reason_code="GEOMETRY_VIOLATION",
        )
    cert = Certificate(
        cert_id=_next_cert_id(),
        plan_hash=child.hash,
        scene_hash=scene.hash,
        dt=child.dt,
        horizon=child.horizon,
        margins=margins,
        method="FULL",
        root_id=None,
        depth=0,
        plan_exact=child.exact_hash,
    )
    return Verdict(
        plan_hash=child.hash,
        verdict="FULL",
        path="full",
        certificate=cert,
        margins=margins,
        full_checks_used=1,
        parent_cert_id=parent_cert_id,
    )


def establish_root(plan: Plan, scene: Scene) -> Verdict:
    """建立父（根）证书：一次完整几何检查。"""
    return _full_path(plan, scene)


class CertificateStore:
    """本地可信证书登记表。

    只接纳本地验证器产生的记录。上游发来的 safe=true、physical_ok=true
    或自选的证书 ID 一律不构成证据。
    """

    def __init__(self, max_entries: int = 10_000):
        if isinstance(max_entries, bool) or not isinstance(max_entries, int) or max_entries < 1:
            raise ValueError("max_entries 必须是正整数")
        self._certs = {}
        self._max_entries = max_entries

    def register(self, cert: Certificate) -> None:
        if not isinstance(cert, Certificate):
            raise TypeError("只接受 Certificate")
        if cert.cert_id not in self._certs and len(self._certs) >= self._max_entries:
            raise ValueError("certificate store capacity exceeded")
        existing = self._certs.get(cert.cert_id)
        if existing is not None and existing != cert:
            raise ValueError("certificate id collision")
        self._certs[cert.cert_id] = cert

    def get(self, cert_id: str) -> Optional[Certificate]:
        return self._certs.get(cert_id)

    def covers(self, cert_id: str, plan_hash: str, plan_exact: Optional[str] = None) -> bool:
        """该证书是否确实覆盖这个最终动作。

        v2：证书记录了被验证计划的逐字节摘要时，要求与最终动作逐字节相同
        （规范化摘要只保留 12 位有效数字，不同字节可以同摘要）。
        """
        cert = self._certs.get(cert_id)
        if cert is None or cert.plan_hash != plan_hash:
            return False
        if plan_exact is not None and cert.plan_exact != plan_exact:
            return False
        if cert.plan_exact is not None and cert.plan_exact != plan_exact:
            return False
        return True

    def __len__(self) -> int:
        return len(self._certs)
